package org.javaro.lecture;
import java.util.Scanner;
/*
class user
{
	public String name; //이름
	public int number;
	user(String name ,int number){
		this.name=name;
		this.number =number;
	}
	public void setname(String name) {this.name= name;}
	public String getname() {return this.name;}
	public void setnumber() {this.number= number;}
	public int	getnumber() {return this.number;}

}
*/
public class PC 
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub	
		program();

	}

	static void program()
	{
		// 회원 정보 =a / 요금 =ab / 자리 = select
		
		System.out.println("┌─────────────────────── 회원 정보를 입력 해주세요 ────────────────────────┐\n");
		System.out.print("회원 : ");
		Scanner username= new Scanner(System.in);
		String a=username.nextLine();
		System.out.println("");
		int f=coinlist();
		place();
		last(a);
		incoin(f);
		System.out.print("1. 종료\t 2. 재시작 \n");
		System.out.print("선택 : ");
		Scanner selection= new Scanner(System.in);
		int sc=selection.nextInt();
		switch(sc)
		{
			case 1:
				System.out.println("프로그램을 종료합니다.");
				break;
			case 2:
				program();
				break;
		}
		
	}
	
	static int coinlist() {
		System.out.println("├─────────────────────── 이용 할 요금을 선택 해주세요 ──────────────────────┤\n");
		System.out.println("\t [ 요금제 ]");
		System.out.println(" 500원 : 30분 / 1000원 : 1시간\n");
		System.out.print("요금 : ");
		Scanner coin= new Scanner(System.in); //\
		int ab= coin.nextInt();
		return ab;
		
	}
	
	static void last(String a)
	{
	System.out.println("이용자 : "+a);
	
	}
	
	
	static void incoin(int a)
	{
	int b=a/500;
	int c=b/2;
	int d=b%2;
	System.out.println("충전 요금 : "+a );
	System.out.println("시간 : "+c+"시간 "+d*30+"분 이용 가능 합니다.");
	}
	
	
	static void place()
	{		
		System.out.println("├─────────────────────── 이용 할 자리를 선택 해주세요 ──────────────────────┤\n");
		for (int f =1; f<=20 ; f++)
		{

			
			System.out.print("["+"□"+"]"+"\t");

			if(f%5==0)
			{
				System.out.println("");
			}
		
		}
		System.out.println("");
		System.out.print("자리 선택 : ");
		Scanner number= new Scanner(System.in); //
		int select= number.nextInt();
		if(0<select&&select<21)
		{
			seat(select);
		}
		else
		{
			System.out.println("├────────────────────────── 없는 좌석 입니다. ─────────────────────────┤\n");
			place();
		}	
		System.out.println("");

	}
	
	static void seat(int a)
{
		
		
		
		for (int f =1; f<=20 ; f++)
			{
				if(f==a)
				{
				System.out.print("["+"■"+"]"+"\t");
				}
				else
				{
				System.out.print("["+"□"+"]"+"\t");
				}
				if(f%5==0)
				{
					System.out.println("");
				}

			}

		
	}
	
}


